define({
  "name": "Control - Rover ABA API Documentation",
  "version": "1.0.0",
  "description": "Rover ABA is a REST API that simulates the control of a Rover sent to Mars to teach English",
  "template": {
    "forceLanguage": "en"
  },
  "sampleUrl": false,
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2019-10-21T22:58:25.482Z",
    "url": "http://apidocjs.com",
    "version": "0.17.7"
  }
});
