define({ "api": [
  {
    "type": "post",
    "url": "/rovers/english",
    "title": "Rover Teach English",
    "group": "Rover",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "englishText",
            "description": "<p>Text that Rover can use in Display</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "JSON Body Example",
          "content": "\n{\"Hello Aliens, I'm ABA Rover\"}",
          "type": "String"
        }
      ]
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Response",
            "description": "<p>Information that Rover teach the text.</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Response",
          "content": "\nRover is displaying the message on his display:{Hello Aliens, I'm ABA Rover}",
          "type": "String"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./com/aba/rover/resource/RoverResource.java",
    "groupTitle": "Rover",
    "name": "PostRoversEnglish"
  },
  {
    "type": "post",
    "url": "/rovers/position",
    "title": "Move Rover",
    "group": "Rover",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "Object[]",
            "optional": false,
            "field": "Movement",
            "description": "<p>Movement do Rover</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "Movement.direction",
            "description": "<p>{'N','S','E','W'}</p>"
          },
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "Movement.units",
            "description": "<p>Units that will advance Rover in indicated direction</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "JSON Body Example",
          "content": "[{\n  \"direction\": \"N\"\n  \"units\": 19\n}]",
          "type": "Object[]"
        }
      ]
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Response",
            "description": "<p>Position about rover</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Response",
          "content": "Position [Latitude=44, Longitude=-8]",
          "type": "String"
        }
      ]
    },
    "error": {
      "fields": {
        "Error 4xx": [
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "InvalidDirection",
            "description": "<p>Invalid direction in the movement</p>"
          },
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "ExceedPosition",
            "description": "<p>Rover Exceed the limit position.</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "./com/aba/rover/resource/RoverResource.java",
    "groupTitle": "Rover",
    "name": "PostRoversPosition"
  }
] });
